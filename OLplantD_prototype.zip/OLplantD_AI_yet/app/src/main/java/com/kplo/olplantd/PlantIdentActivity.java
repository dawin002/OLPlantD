package com.kplo.olplantd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PlantIdentActivity extends AppCompatActivity {
    TextView TextView_Plant_Ident;
    Button btn_yes;
    Button btn_no;
    int seqnum =0;
    int[]count = {0,0,0,0,0,0,0,0,0,0};
    public int plantresult(int [] count,int size){
        int temp;
        int index=0;
        temp = count[0];
        for (int i=0;i<size;i++){
            if (temp < count[i]){
                temp = count[i];
                index = i;
            }
        }
        return index;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plant_ident);
        PlantInit.initDB();
        Intent intent = new Intent(PlantIdentActivity.this, SuggestActivity.class);

        PlntQuestion[] askQues = new PlntQuestion[7];
        // intent 선언하기
        askQues[0] = new PlntQuestion("꽃이 폈습니까?","6 ");
        askQues[1] = new PlntQuestion("열매가 있습니까?","6 ");
        askQues[2] = new PlntQuestion("꽃이 노란색입니까?","yellow ");
        askQues[3] = new PlntQuestion("나무입니까?","wood ");
        askQues[4] = new PlntQuestion("줄기에 털이 있습니까?","hair ");
        askQues[5] = new PlntQuestion("잎이 어긋나기 입니까?","auget ");
        askQues[6] = new PlntQuestion("잎의 모양이 부채모양입니까?","fan ");
        btn_no = findViewById(R.id.btn_no);
        btn_yes = findViewById(R.id.btn_yes);

        TextView_Plant_Ident = findViewById(R.id.TextView_Plant_Ident);
        TextView_Plant_Ident.setText(askQues[0].getQuLine());

        btn_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (seqnum){
                    case 0: for(int i=0;i<10;i++){ if (PlantInit.plantDB[i].getBloom().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                    case 1:for(int i=0;i<10;i++){ if (PlantInit.plantDB[i].getFruit().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                    case 2:for(int i=0;i<10;i++){ if (PlantInit.plantDB[i].getFlowerColor().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                    case 3:for(int i=0;i<10;i++){ if (PlantInit.plantDB[i].getTree().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                    case 4:for(int i=0;i<10;i++){ if (PlantInit.plantDB[i].getStem().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                    case 5:for(int i=0;i<10;i++){ if (PlantInit.plantDB[i].getLeafNagi().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                    case 6:for(int i=0;i<10;i++){ if (PlantInit.plantDB[i].getLeafShape().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                }

                seqnum ++;

                if (seqnum == 7){
                    intent.putExtra("plant_name", PlantInit.plantDB[plantresult(count,10)].getSciName());
                    startActivity(intent); // 엑티비티이동
                    finish();
                }
                else
                    TextView_Plant_Ident.setText(askQues[seqnum].getQuLine());
            }
        });
        btn_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (seqnum){
                    case 0: for(int i=0;i<10;i++){ if (!PlantInit.plantDB[i].getBloom().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                    case 1:for(int i=0;i<10;i++){ if (!PlantInit.plantDB[i].getFruit().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                    case 2:for(int i=0;i<10;i++){ if (!PlantInit.plantDB[i].getFlowerColor().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                    case 3:for(int i=0;i<10;i++){ if (!PlantInit.plantDB[i].getTree().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                    case 4:for(int i=0;i<10;i++){ if (!PlantInit.plantDB[i].getStem().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                    case 5:for(int i=0;i<10;i++){ if (!PlantInit.plantDB[i].getLeafNagi().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                    case 6:for(int i=0;i<10;i++){ if (!PlantInit.plantDB[i].getLeafShape().equals(askQues[seqnum].getValue())) count[i]++; }
                        break;
                }

                seqnum++;
                if (seqnum == 7){
                    intent.putExtra("plant_name", PlantInit.plantDB[plantresult(count,10)].getSciName());
                    startActivity(intent); // 엑티비티이동
                    finish();
                }else
                    TextView_Plant_Ident.setText(askQues[seqnum].getQuLine());
            }

        });

    }
}
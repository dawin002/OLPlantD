package com.kplo.olplantd;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


public class AIActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aiactivity);
    }
}
package com.kplo.olplantd;

import android.app.Activity;

public class activity_plant_dic extends Activity {
}

package com.kplo.olplantd;


import java.util.Scanner;
import java.util.StringTokenizer;


class PlantInit {
    public static int MAX_SIZE_PLANT = 10; // 식물 최대 갯수,
    public static int MAX_SIZE_PLANT_CHARACTER = 14;
    public static PlntData plantDB[] = new PlntData[10]; // ******************* 선언위치 잘생각해봐라 ************ 다음에 오자마자하기
    // 전역변수로 식물특징 클레스 배열 선언

    public static void initDB(){
        // 파일을 입력받아서 객체 5천개 만든후 배열에 1번부터 저장하고 배열 넘기기
        //파일을 useDelimiter("#")을 이용하여 하나의 식물을 받아오고
        // tokenizer을 이용하여 각각의 특징을 하나씩 받아온다.

            String plantCharacter =
                    "# @소나무 @PinusdensifloraSiebold @pinus @pinaceae @pinales @pinopsida @gymnospermae @5 @5 @brown @wood @non @non @needle " +
                    "# @포도 @VitisviniferaL. @vitis @Vitaceae @Rhamnales @Dicotyledoneae @Angiospermae @6 @6 @green @wood @hair @auget @round " +
                    "# @장미 @RosabanksiaeAiton @Rosa @Rosaceae @Rosales @Dicotyledoneae @Angiospermae @6 @8 @red @wood @thron @auget @round " +
                    "# @민들레 @HelianthusannuusL. @Helianthus @Compositae @Campanulales @Dicotyledoneae @Angiospermae @6 @6 @yellow @gress @non @non @round " +
                    "# @해바라기 @Helianthusannuus @Helianthus @Compositae @Campanulales @Dicotyledoneae @Angiospermae @8 @8 @yellow @gress @hair @auget @round " +
                    "# @강아지풀 @SetariaviridisL. @Setaria @Gramineae @Graminales @Monocotyledoneae @Angiospermae @7 @7 @green @gress @non @yupcho @non " +
                    "# @은행나무 @Ginkgobiloba @Ginkgo @Gingkoaceae @Ginkgoales @Ginkgoopsida @Ginkgophyta @5 @5 @green @wood @non @auget @fan " +
                    "# @개나리 @Forsythiakoreana @Forsythia @Oleaceae @Gentianales @Dicotyledoneae @Anthophyta @4 @4 @yellow @gress @non @maju @round " +
                    "# @무궁화 @HibiscussyriacusL. @Hibiscus @Malvaceae @Malvales @Magnoliopsida @Magnoliophyta @8 @8 @purple @wood @non @auget @round " +
                    "# @샤스타데이지 @ChrysanthemumburbankiiMakino @Chrysanthemum @ASTERACEAE @ASTERALES @MAGNOLIOPSIDA @MAGNOLIOPHYTA @6 @6 @white @gress @non @auget @round ";
            Scanner scanner = new Scanner(plantCharacter);// 대충 파일 14개씩 받기
            // "UTF-8"을 이용해야지 한글을 읽어올 수 있다.

            scanner.useDelimiter("#");
            for(int i=0;scanner.hasNext();i++){
                String onePlant = scanner.next();
                StringTokenizer st = new StringTokenizer(onePlant,"@",false);
                String PlantCh[] = new String[MAX_SIZE_PLANT_CHARACTER];
                st.nextToken();
                for(int j=0;j<MAX_SIZE_PLANT_CHARACTER;j++){
                    PlantCh[j] = st.nextToken();
                }
                plantDB[i] = new PlntData(PlantCh[0],PlantCh[1],PlantCh[2],PlantCh[3],PlantCh[4],PlantCh[5],PlantCh[6],PlantCh[7],PlantCh[8],PlantCh[9],PlantCh[10],PlantCh[11],PlantCh[12],PlantCh[13]);
            }


    }
}
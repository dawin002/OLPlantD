package com.kplo.olplantd;

import java.util.ArrayList;
import java.util.List;

class Plant{
    private String name;

    public Plant(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }

    public void setName(String name){
        this.name = name;
    }

}

public class DB_PlantList {
    List<Plant> pList;
    DB_PlantList(){
        this.pList = new ArrayList<>();
    }

    public void setup(){
        addPList("해바라기");
        addPList("서양해바라기");
        addPList("함박해바라기");
        addPList("매우해바라기");
        addPList("감자");
        addPList("돼지감자");
        addPList("밥풀감자");
        addPList("민들레");
        addPList("서양민들레");
        addPList("흰털민들레");
        addPList("장미");
        addPList("목향장미");
        addPList("덩굴장미");
        addPList("파란장미");
        addPList("노란장미");
        addPList("빨간장미");
        addPList("검정장미");
        addPList("하얀장미");
        addPList("초록장미");
        addPList("소나무");
        addPList("일본소나무");
        addPList("중국소나무");
        addPList("서양소나무");
        addPList("바다소나무");
        addPList("산민들레");
        addPList("붉은씨서양민들레");
        addPList("좀민들레");
        addPList("털민들레");
        addPList("흰민들레");
    }

    public void addPList(String str){
        Plant tmp = new Plant(str);
        this.pList.add(tmp);
    }
}
